from django import forms
from .models import Equipos
from .models import Jugadores
from .models import Estadios

class FormRegEquipo(forms.ModelForm):
	class Meta:
		model = Equipos
		fields = ["nombre_equipo", "fecha_creacion", "cd", "fundador",
		"director", "foto_equipo"]
			
class FormRegJugador(forms.ModelForm):
	class Meta:
		model = Jugadores
		fields = ["nombre_jugador", "edad", "posicion", "equipo", 
		"foto_jugador"]

class FormRegEstadio(forms.ModelForm):
	class Meta:
		model = Estadios
		fields = ["nombre_estadio", "fecha_construccion", "direccion", 
		"propietario", "foto_estadio"]