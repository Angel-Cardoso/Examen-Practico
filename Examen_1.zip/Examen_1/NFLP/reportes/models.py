from django.db import models

# Create your models here.

class Equipos(models.Model):
	nombre_equipo = models.CharField(max_length = 40)
	fecha_creacion = models.DateTimeField()
	cd = models.CharField(max_length = 20)
	fundador = models.CharField(max_length = 30)
	director = models.CharField(max_length = 30)
	fecha_registro = models.DateTimeField(auto_now_add = True)
	foto_equipo = models.ImageField(blank=True, null=True, upload_to="fotos_equipos/%Y/")
	def __str__(self):
		return str(self.nombre_equipo)

class Jugadores(models.Model):
	nombre_jugador = models.CharField(max_length = 40)
	edad = models.FloatField()
	posicion = models.CharField(max_length = 15)
	equipo = models.ForeignKey(Equipos, on_delete=models.CASCADE)
	fecha_registro = models.DateTimeField(auto_now_add = True)
	foto_jugador = models.ImageField(blank=True, null=True, upload_to="fotos_jugadores/%Y/")
	def __str__(self):
		return str(self.nombre_jugador)

class Estadios(models.Model):
	nombre_estadio = models.CharField(max_length = 30)
	fecha_construccion = models.DateTimeField()
	direccion = models.CharField(max_length = 25)
	foto_estadio = models.ImageField(blank=True, null=True, upload_to="fotos_estadios/%Y/")	
	propietario = models.CharField(max_length = 30)
	fecha_registro = models.DateTimeField(auto_now_add = True)
	def __str__(self):
		return str(self.nombre_estadio)
						
