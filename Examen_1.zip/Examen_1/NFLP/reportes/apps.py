from django.apps import AppConfig


class ReportesConfig(AppConfig):
    name = 'reportes'
