from django.shortcuts import render
from .models import Jugadores
from .models import Estadios
from .models import Equipos
from .forms import FormRegEquipo
from .forms import FormRegJugador
from .forms import FormRegEstadio

# Create your views here.
def index(request):
	return render(request, "reportes/index.html")

def nflp(request):
	return render(request, "inicio/nflp.html")

def estadios_list(request):
	queryset = Estadios.objects.all()
	return render(request, "reportes/estadios.html",{ "Estadios" : queryset})

def equipos_list(request):
	queryset = Equipos.objects.all()
	return render(request, "reportes/equipos.html", { "Equipos" : queryset})

def jugadores_list(request):
	queryset = Jugadores.objects.all()
	return render(request, "reportes/jugadores.html", { "Jugadores": queryset})

def detalle_jugador(request, id=1):
	queryset = Jugadores.objects.get(id=id)
	return render(request, "reportes/detalle_jugador.html", { "Detalle" : queryset})

def detalle_equipo(request, id=1):
	queryset = Equipos.objects.get(id=id)
	return render(request, "reportes/detalle_equipo.html", {"Detalle" : queryset})

def detalle_estadio(request, id=1):
	queryset = Estadios.objects.get(id=id)
	return render(request, "reportes/detalle_estadio.html", {"Detalle" : queryset})

def registrar_equipo(request):
	form = FormRegEquipo(request.POST or None)
	if form.is_valid():
		instance = form.save(commit=False)
		instance.user = request.user
		instance.save()
	# equipo = {"form": form}
	return render(request, "reportes/registrar_equipo.html", {"form": form})

def registrar_jugador(request):
	form = FormRegJugador(request.POST or None)
	if form.is_valid():
		instance = form.save(commit=False)
		instance.user = request.user
		instance.save()
	# equipo = {"form": form}
	return render(request, "reportes/registrar_jugador.html", {"form": form})

def registrar_estadio(request):
	form = FormRegEstadio(request.POST or None)
	if form.is_valid():
		instance = form.save(commit=False)
		instance.user = request.user
		instance.save()
	# equipo = {"form": form}
	return render(request, "reportes/registrar_estadio.html", {"form": form})