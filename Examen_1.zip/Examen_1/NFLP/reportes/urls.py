from django.contrib import admin
from django.urls import path
from reportes import views

urlpatterns = [
    path('reportes/', views.index, name='index_views'),
    path('', views.nflp, name='nflp_views'),
    path('estadios_list/', views.estadios_list, name ='estadios_views'),
    path('jugadores_list/', views.jugadores_list, name ='jugadores_views'),
    path('equipos_list/', views.equipos_list, name ='equipos_views'),
    path('detalle_jugador/<int:id>/', views.detalle_jugador, name ='detalle_jugador_views'),
    path('detalle_equipo/<int:id>/', views.detalle_equipo, name ='detalle_equipo_views'),
    path('detalle_estadio/<int:id>/', views.detalle_estadio, name ='detalle_estadio_views'),
    path('registrar_equipo/', views.registrar_equipo, name ='registrar_equipo_views'),
    path('registrar_jugador/', views.registrar_jugador, name ='registrar_jugador_views'),
    path('registrar_estadio/', views.registrar_estadio, name ='registrar_estadio_views')
]