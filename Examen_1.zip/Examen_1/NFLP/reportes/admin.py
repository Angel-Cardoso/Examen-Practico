from django.contrib import admin

# Register your models here.
from .models import Estadios
from .models import Jugadores
from .models import Equipos

admin.site.register(Estadios)
admin.site.register(Jugadores)
admin.site.register(Equipos)